
const questions = [
    {
        question: "What is the capital of India?",
        options: ["Mumbai", "Delhi", "Chennai", "Kolkata"],
        answer: "Delhi"
    },
    {
        question: "Which language is used for web styling?",
        options: ["HTML", "Java", "CSS", "Python"],
        answer: "CSS"
    },
    {
        question: "Which tag is used for JavaScript?",
        options: ["<js>", "<script>", "<javascript>", "<code>"],
        answer: "<script>"
    }
];

let currentQuestion = 0;
let score = 0;

const questionText = document.getElementById("question");
const optionButtons = document.querySelectorAll(".option-btn");
const nextBtn = document.getElementById("next-btn");
const scoreText = document.getElementById("score");

function loadQuestion() {
    const q = questions[currentQuestion];
    questionText.textContent = q.question;
    optionButtons.forEach((btn, i) => {
        btn.textContent = q.options[i];
        btn.onclick = () => checkAnswer(q.options[i]);
    });
}

function checkAnswer(selected) {
    if (selected === questions[currentQuestion].answer) {
        score++;
    }
    currentQuestion++;
    if (currentQuestion < questions.length) {
        loadQuestion();
    } else {
        showScore();
    }
}

function showScore() {
    questionText.style.display = "none";
    document.querySelector(".options").style.display = "none";
    nextBtn.style.display = "none";
    scoreText.textContent = `You scored ${score} out of ${questions.length}! 🎉`;
}

nextBtn.onclick = () => {
    if (currentQuestion < questions.length) {
        loadQuestion();
    }
};

loadQuestion();
